<?php
    session_start();
	if(isset($_SESSION['uid'])==1)
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
    include('header.php'); 
    
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Add Board</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="../fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="../css/style.css">
	</head>

	<body>

        <div class="wrapper" style="background-image: url('../image/bg-registration-form-2.jpg');
        margin-left:234px;margin-top:-140px;">
			<div class="inner">
				<form action="add_member.php" method="POST">
					<h3 style="margin-top:-30px;margin-left:142px;">Enter Member Details</h3>
					<div class="form-group" style="margin-left:-65px;">
						<div class="form-wrapper">
							<label >Name</label>
							<input type="text" class="form-control" name="name">
						</div>
                        <div class="form-wrapper">
						<label >Email</label>
						<input type="email" class="form-control" name="email">
					</div>
                    <div class="form-wrapper" style="margin-left:20px;">
						<label >Mobile</label>
						<input type="tel" class="form-control" name="mobile">
                    </div>
                    </div>
                    

                    <div class="form-group" style="margin-left:-65px;">
						
					
                    <div class="form-wrapper" style="margin-left:2px;">
						<label >CGPA</label>
						<input type="number" class="form-control" name="cgpa">
					</div>
					<div class="form-wrapper" style="margin-left:4px;">
						<label >Stream</label>
						<input type="text" class="form-control" name="stream">
                    </div>
                    <div class="form-wrapper" style="margin-left:20px;">
						<label >Passing Year</label>
						<input type="number" class="form-control" name="pyear">
					</div>
					</div>
					
					<button name="addmember" style="margin-left:187px;">Add Member</button>
				</form>
			</div>
		</div>
		
	</body>
</html>

<?php 

	include('../dbcon.php');

	if(isset($_POST['addmember'])){

	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$cgpa=$_POST['cgpa'];
	$role=$_POST['stream'];
	$pyear=$_POST['pyear'];

	$qry2="INSERT INTO member (email,name ,mobile,stream,cgpa,passingyear) VALUES ('$email','$name','$mobile','$role','$cgpa','$pyear')";
	$run2=mysqli_query($con,$qry2);
	if($run2){
	?><script>alert("Records Inserted Succesfully")</script>
	<?php
		}
	}
?>