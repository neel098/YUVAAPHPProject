<?php

  $id=$_REQUEST['did'];
    include('../dbcon.php');
    $qry4="DELETE  FROM member WHERE mid=$id";
    $run4=mysqli_query($con,$qry4);
    if($run4==true){
        header('location:remove_member.php');
    }
?>