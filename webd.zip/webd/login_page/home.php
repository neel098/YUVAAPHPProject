<?php
    session_start();
    if(isset($_SESSION['uid'])){
        echo " ";
    }
    else{
        header('location:../index.php');
    }
    if($_SESSION['uid']==1){
        header('location:ceo.php');
    }
    elseif($_SESSION['uid']==2){
        header('location:hr.php');
    }elseif($_SESSION['uid']==3){
        header('location:event.php');
    }else{
        echo " ";
    }
    include('dbcon.php');
    
?>

