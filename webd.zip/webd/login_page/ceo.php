<?php
	
	session_start();
	if(isset($_SESSION['uid'])==1)
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
	include('../dbcon.php');

	$id=$_SESSION['uid'];

	$qry="SELECT * FROM `adminlogin` WHERE id='$id'";
	$run=mysqli_query($con,$qry);
	$data=mysqli_fetch_assoc($run);	

	if(empty($data['image'])){
		$data['image']="dataimg\default_profile.png";
	}
	include('header.php'); 
?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<style>
			@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700italic);

		*{margin: 0px; padding: 0px}

		body{
		background:#2c3e50;
		font-family: 'Open Sans', sans-serif;
		}

		h1, button{
		color:#fff;
		text-align: center;
		padding: 20px;
		}

		p{
		color:#fff;
		text-align: center;
		padding-top: 500px;
		font-size: 10px;
		}

		a{
		text-decoration:none;
		color:#fff;
		}

		a:hover{
		color:#2ecc71;
		}

		.main{
		width: 100%;
		}

		.sub-main{
		width: 30%;
		margin:22px;
		float: left;
		}

		.button-one{
		text-align: center;
		cursor: pointer;
		font-size:24px;
		margin: 0 0 0 100px;
		}



		/*Button One*/
		.button-one {
		padding:20px 60px;
		outline: none;
		background-color: #27ae60;
		border: none;
		border-radius:5px;
		box-shadow: 0 9px #95a5a6;
		}

		.button-one:hover{
		background-color: #2ecc71;
		}

		.button-one:active {
		background-color: #2ecc71;
		box-shadow: 0 5px #95a5a6;
		transform: translateY(4px);
		}

		</style>
	</head>

	<body>
		
	
		<div style="margin-left: -100px;margin-top:-140px;">

		<div>
    <div class="sub-main">
    	<a href="view_board.php">
      <button class="button-one" style="width:313px;">View Board</button></a>
	</div>
	
	<div class="sub-main">
    	<a href="add_board.php">
      <button class="button-one" style="width:313px;margin-left:-30px;">Add Board</button></a>
    </div>
    <div class="sub-main">
    	<a href="remove_board.php">
      <button class="button-one" style="width:313px;margin-left:-160px;">Remove Board</button></a>
    </div>
</div>


<div>
    <div class="sub-main">
    	<a href="view_member.php">
      <button class="button-one" style="width:313px;">View Member</button></a>
	</div>
	<div class="sub-main">
    	<a href="add_member.php">
      <button class="button-one" style="width: 313px;margin-left:-30px;">Add Member</button></a>
    </div>
    <div class="sub-main">
    	<a href="remove_member.php">
      <button class="button-one" style="width:313px;margin-left:-160px;">Remove Member</button></a>
    </div>
</div>


<div>
    <div class="sub-main">
    	<a href="view_event.php">
      <button class="button-one" style="width:313px;">View Event</button></a>
	</div>
	<div class="sub-main">
    	<a href="add_event.php">
      <button class="button-one" style="width: 313px;margin-left:-30px;">Add Event</button></a>
    </div>
    <div class="sub-main">
    	<a href="#">
      <button class="button-one" style="width:313px;margin-left:-160px;">Remove Event</button></a>
    </div>
</div>
</div>
</body>
</html>


