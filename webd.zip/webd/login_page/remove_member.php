<?php
    session_start();
	if(isset($_SESSION['uid'])==1)
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
	include('../dbcon.php');

    include('header.php'); 
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>View Board</title>
	<style>
	
		
	</style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body style="background-color:lightgray;">
	
</body>
</html>

<?php  


$qry1="SELECT * FROM member ";
$run1=mysqli_query($con,$qry1);



while($data1=mysqli_fetch_assoc($run1)){ ?>


	<?php if(empty($data1['image'])){
		$data1['image']="..\dataimg\default_profile.png";
	} ?>
        <div style="display:inline-block;margin-left:40px;margin-top:-140px;">
        <div style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);height:370px;">
         <div style="margin-left:40px;"><img src=" <?php echo $data1['image'] ?> " alt="John" style="width:80%;border-radius:50%">  </div>
         <div style="margin-left:63px;"> <h3><?php echo $data1['name'] ?></h3> </div>
         <div style="margin-left:40px;"> E-Mail:<?php echo $data1['email'] ?></div>
         <div style="margin-left:40px;"> Mobile:<?php echo $data1['mobile'] ?></div>
         <div style="margin-left:40px;"> Stream:<?php echo $data1['stream'] ?></div>
         <div style="margin-left:40px;"> CGPA:<?php echo $data1['cgpa'] ?></div>
         <div style="margin-left:40px;"> Passing Year:<?php echo $data1['passingyear'] ?></div>
         <a href="remove_member_data.php?did=<?php  echo $data1['mid']; ?>"
      <button type="button" class="btn btn-danger" style="margin-left:-3.5px;margin-top:15px;border-radius:24px;
      padding-right:70px;padding-left:70px;">Delete Member</button></a>
        </div>

        </div>

<?php
}
?>