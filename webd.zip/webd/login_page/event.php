<?php
	
	session_start();
	if(isset($_SESSION['uid'])==3)
	{
		echo "";
	}
	else{
		header('location:../index.php');
	}
	include('../dbcon.php');

	$id=$_SESSION['uid'];

	$qry="SELECT * FROM `adminlogin` WHERE id='$id'";
	$run=mysqli_query($con,$qry);
	$data=mysqli_fetch_assoc($run);	

	if(empty($data['image'])){
		$data['image']="dataimg\default_profile.png";
	}
	include('header.php');
?>

